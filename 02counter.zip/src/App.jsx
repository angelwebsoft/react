import { useState } from 'react'
import './App.css'

function App() {
const [counter, setcounter] = useState(15);

const increaseValue = () =>{
  if(counter <= 19 ){
    setcounter(counter + 1)
  }
}
const decreaseValue = () =>{
  if(counter >= 1 ){
    setcounter(counter - 1)
  }
}
  
  return (
    <>
    <button onClick={increaseValue}><h3>+</h3></button>
      <h1>{counter}</h1>
    <button onClick={decreaseValue}><h3>-</h3></button>
    </>
  )
}

export default App
